// C++ db hierarchy sample

/* Client DB identified so far:

- ItemDB
- MonstersDB
- HairStylesDB
- ColorsDB
- HairStylesColorDB
- WeaponsTypesDB
- EmoteDB
- NpcDB
- SkillDB
- RacesDB
- SpecialDB
- RunesDB

Their common configuration is their Id and their names. What's left is specific
to the DB.
Under eAthena, and only under it, the race, item, WeaponsTypes, hairstyles must not have 
the same id, and race and hairstyle ID must be negative within a given range.
A one-shot function should deal with that, so the player/content manager has a clear output
when doing something wrong with the eAthena db specifities.

To be fully flexible and understanbable, each db should be read from a separate XML file,
as it is already for most, but not every.

The cpp/hpp files concerned here should be kept into the ressources/db folder
to gather the same type of data and clearly state the link between them.

Here a conceptual proposal to handle this while keeping in mind flexibility and 
code readability.
*/

#include <string>
namespace DB {

// DB
class DBRecord
{
    public:
        virtual DBRecord(id, name):
        mId(id), mName(name)
        {}
    
        virtual DBRecord()
        {}
            
        virtual int id() const
        { return mId; }
        
        virtual std::string name() const
        { return mName; }
    
    private:
        int mId;
        std::string mName;
}

class DB
{
    public:
        
        enum DBType
        {
            ITEM_DB = 0,
            MONSTER_DB,
            // ...
            NB_DB
        }
    
        static char *dbConfigValues[2][NB_DB] =
        { {"ItemDBFile", "items.xml"},
           {"monsterDBFile", "monsters.xml"}
           // ...
        };
        
        virtual int id(const std::string name) const = 0;
        virtual std::string name(const int id) const = 0;
    
        virtual DBType type() const;
    
        virtual initDB(std::string &xmlFile) = 0;
        virtual deinitDB(std::string &xmlFile) = 0;
};

// ItemDB
class ItemInfo : public DBRecord
{
        //...
};

class ItemDB : public DB
{
    public:

    //...
    
   private:
       std::map<int, ItemInfo *> mItemDB;
};

// ColorsDB
class ColorInfo : public DBRecord
{
        //...
};

class HairColorInfo : public DBRecord
{
        //...
    private:
        ColorInfo *mFallBackColor;
};

class HairStyleDB : public DB
{
    public:

    //...
    
   private:
       std::map<int, HairColorInfo *> mHairColorDB;
};

class ColorDB : public DB
{
    public:

    //...
    
   private:
       std::map<int, ItemInfo *> mColorDB;
};

// ...

static bool checkEathenaSpecificId(ItemDB *itemDB, RaceDB *raceDB,
                                                 WeaponTypeDB *wtDB,
                                                 HairstylesDB *hairstylesDB)
{
    // Return true when the eAthena id specificities are followed.
    // or false with log output when something is wrong concerning the databases id.
    // TODO: Load every IDs and check for their unicity and their ranges according to their types.
    return true;
}

#include "configuration.h"
class DatabaseManager
{
    public:
        DatabaseManager():
        mInitialized(false) {}
    
        static DatabaseManager *instance()
        { return this; }

        ItemDB *itemDB() const
        { return mItemDB; }
        
        MonsterDB *monsterDB() const
        { return mMonsterDB; }
        
        void deinitDB();
        {
            mInitialized = false;
            if (mItemDB) delete mItemDB;
            mItemDB = 0;
            if (mMonsterDB) delete mMonsterDB;
            mMonsterDB = 0;
            // ...
        }
        
        bool initDB(Configuration *branding)
        {
            // Reload if already loaded.
            if (mIinitialized)
                deinitDB();
            
            mInitialized = true;
            for (int i = Database::ITEM_DB; i < Database::NB_DB; i++)
            {
                switch(i)
                {
                    case ITEM_DB:
                        _initDB(mItemDB, i);
                        break;
                    case MONSTER_DB:
                        _initDB(mMonsterDB, i);
                        break;                        
                        //...
                    
                    default:
                        logger->log("DatabaseManager: Unknown database init call, id: %i. Ignoring...", i);
                }
                
            }
            return mInitialized;
        }
        
        bool checkEathenaSpecificId();
        {
            // DB Concerned: ItemDB, RaceDB, WeaponTypeDB, HairstylesDB
            // Return true when the eAthena id specificities are followed.
            // or false with log output when something is wrong concerning the databases id.
            // TODO: Load every IDs and check for their unicity and their allowed ranges according to their types.
            return true;
        }
        
    private:
        // Tells if the manager is initialized.
        bool mInitialized;
    
        template <class T>
        void _initDB(T* Db, Database::DBType dBType)
        {
            Db = new Db(branding.getValue(DB::dbConfigValues[0][dBType],
                                                         DB::dbConfigValues[1][dBType]));
            if (mInitialized)
                mInitialized = Db->initialized();
        }
    
        // each DB
        ItemDB *mItemDB;
        MonsterDB *mMonstersDB;
        HairstyleDB *mHairStylesDB;
        ColorDB *mColorDB;
        WeaponTypeDB *mWeaponTypeDB;
        EmoteDB *mEmoteDB;
        NpcDB *mNpcDB;
        RacesDB *mRaceDB;

        SpecialDB *mSpecialDB;
        SkillDB *mSkillDB;
        RuneDB *mRuneDB;
};

} // Namespace DB